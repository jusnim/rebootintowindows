/* extension.js
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
/* exported init */
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Clutter from 'gi://Clutter';
import St from 'gi://St';
import Pango from 'gi://Pango';
import { panel } from 'resource:///org/gnome/shell/ui/main.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import * as ModalDialog from 'resource:///org/gnome/shell/ui/modalDialog.js';
import { Extension, gettext as _, } from 'resource:///org/gnome/shell/extensions/extension.js';
const GRUB_CONFIG_PATH = "/boot/grub/grub.cfg";
export default class RebootToWindowsExtension extends Extension {
    menu;
    proxy;
    rebootToWindowsItem;
    counter;
    seconds;
    counterIntervalId;
    messageIntervalId;
    sourceId;
    manager;
    constructor(metadata) {
        super(metadata);
    }
    modifySystemItem() {
        this.menu =
            panel.statusArea.quickSettings?._system?.quickSettingsItems[0].menu;
        // if(this.manager == null){
        //   return
        // }
        this.proxy = this.manager(Gio.DBus.system, 'org.freedesktop.login1', '/org/freedesktop/login1');
        this.rebootToWindowsItem = new PopupMenu.PopupMenuItem(`${_('Restart to Windows')}...`);
        this.rebootToWindowsItem.connect('activate', () => {
            this.counter = 60;
            this.seconds = this.counter;
            const dialog = this.buildDialog();
            dialog.open();
            this.counterIntervalId = setInterval(() => {
                if (this.counter > 0) {
                    this.counter--;
                    if (this.counter % 10 === 0) {
                        this.seconds = this.counter;
                    }
                }
                else {
                    this.clearIntervals();
                    this.reboot();
                }
            }, 1000);
        });
        this.menu.addMenuItem(this.rebootToWindowsItem, 2);
    }
    queueModifySystemItem() {
        this.sourceId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
            if (!panel.statusArea.quickSettings?._system)
                return GLib.SOURCE_CONTINUE;
            this.modifySystemItem();
            return GLib.SOURCE_REMOVE;
        });
    }
    enable() {
        const ManagerInterface = `<node>
  <interface name="org.freedesktop.login1.Manager">
    <method name="Reboot">
      <arg type="b" direction="in"/>
    </method>
  </interface>
  </node>`;
        this.manager = Gio.DBusProxy.makeProxyWrapper(ManagerInterface);
        if (!panel.statusArea.quickSettings?._system) {
            this.queueModifySystemItem();
        }
        else {
            this.modifySystemItem();
        }
    }
    disable() {
        this.manager = null;
        this.clearIntervals();
        this.rebootToWindowsItem?.destroy();
        this.rebootToWindowsItem = null;
        this.proxy = null;
        if (this.sourceId) {
            GLib.Source.remove(this.sourceId);
            this.sourceId = null;
        }
    }
    get_windows_grub_entry(file_path) {
        try {
            const [, stdout, , status] = GLib.spawn_command_line_sync(`cat "${file_path}"`);
            if (status !== 0 || !stdout) {
                console.error(`RebootToWindows: Failed to read ${file_path} or file is empty.`);
                return "";
            }
            const contentsText = new TextDecoder('utf-8').decode(stdout);
            const arr = contentsText.split(/\r?\n/);
            for (const line of arr) {
                const trimmed = line.trim();
                if (trimmed.includes("menuentry") && trimmed.toLowerCase().includes("windows")) {
                    const firstQuote = trimmed.indexOf("'") !== -1 ? trimmed.indexOf("'") : trimmed.indexOf('"');
                    if (firstQuote !== -1) {
                        const secondQuote = trimmed.indexOf(trimmed[firstQuote], firstQuote + 1);
                        if (secondQuote !== -1) {
                            return trimmed.substring(firstQuote + 1, secondQuote);
                        }
                    }
                }
            }
            return "";
        }
        catch (e) {
            console.error(`RebootToWindows: Error reading ${file_path}`, e);
            return "";
        }
    }
    async reboot() {
        try {
            this.clearIntervals();
        }
        catch (e) {
            // ignore
        }
        try {
            let windows_grub_entry = this.get_windows_grub_entry(GRUB_CONFIG_PATH);
            if (!windows_grub_entry) {
                throw new Error(_('Windows GRUB entry not found. Please ensure os-prober is enabled and run sudo update-grub.'));
            }
            const [, argv] = GLib.shell_parse_argv(`pkexec grub-reboot "${windows_grub_entry}"`);
            if (!argv) {
                throw new Error(`Could not parse shell command. Found GRUB entry was: "${windows_grub_entry}"`);
            }
            const proc = Gio.Subprocess.new(argv, Gio.SubprocessFlags.NONE);
            await proc.wait_check_async(null);
            this.proxy?.RebootRemote(true);
        }
        catch (e) {
            this.clearIntervals();
            console.error(`RebootToWindows Error:`, e);
            const errorDialog = new ModalDialog.ModalDialog({ styleClass: 'modal-dialog' });
            const label = new St.Label({
                text: _(`Error: ${e.message || e}`),
            });
            label.clutterText.lineWrap = true;
            errorDialog.contentLayout.add_child(label);
            errorDialog.setButtons([
                {
                    label: _('OK'),
                    action: () => errorDialog.close(),
                    default: true,
                },
            ]);
            errorDialog.open();
        }
    }
    buildDialog() {
        const dialog = new ModalDialog.ModalDialog({ styleClass: 'modal-dialog' });
        dialog.setButtons([
            {
                label: _('Cancel'),
                action: () => {
                    this.clearIntervals();
                    dialog.close();
                },
                key: Clutter.KEY_Escape,
                default: false,
            },
            {
                label: _('Restart'),
                action: () => {
                    this.clearIntervals();
                    this.reboot();
                },
                default: false,
            },
        ]);
        const dialogTitle = new St.Label({
            text: _('Restart into Windows'),
            // style_class: 'dialog-title' // TODO investigate why css classes are not working
            style: 'font-weight: bold;font-size:18px',
        });
        let dialogMessage = new St.Label({
            text: this.getDialogMessageText(),
        });
        dialogMessage.clutterText.ellipsize = Pango.EllipsizeMode.NONE;
        dialogMessage.clutterText.lineWrap = true;
        const titleBox = new St.BoxLayout({
            xAlign: Clutter.ActorAlign.CENTER,
        });
        titleBox.add_child(new St.Label({ text: '  ' }));
        titleBox.add_child(dialogTitle);
        let box = new St.BoxLayout({ yExpand: true, vertical: true });
        box.add_child(titleBox);
        box.add_child(new St.Label({ text: '  ' }));
        box.add_child(dialogMessage);
        this.messageIntervalId = setInterval(() => {
            dialogMessage?.set_text(this.getDialogMessageText());
        }, 500);
        dialog.contentLayout.add_child(box);
        return dialog;
    }
    getDialogMessageText() {
        return _(`The system will restart automatically in %d seconds.`).replace('%d', String(this.seconds));
    }
    clearIntervals() {
        clearInterval(this.counterIntervalId);
        clearInterval(this.messageIntervalId);
    }
}
